export const messageKeys = {
  START_EXTENSION: 0,
  STOP_EXTENSION: 1,
  PLAY_SOUND: 2,
  SKIP_REST: 3,
}
